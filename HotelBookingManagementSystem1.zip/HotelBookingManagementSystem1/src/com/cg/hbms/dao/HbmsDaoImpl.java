package com.cg.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.util.DbConnection;

public class HbmsDaoImpl implements IHbmsDao {
	static Connection connection;
	static Logger logger;

	static {
		PropertyConfigurator.configure("src//log4j.properties");
		logger = Logger.getRootLogger();
	}
	
	
	
	

	@Override
	public User registerUser(User user) throws HbmsException {
		connection = DbConnection.getConnection();
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement2 = null;
		ResultSet resultSet =null;
		Integer userId = 0;
		 
		int queryResult=0;
		try{
			preparedStatement=connection.prepareStatement(QueryMapper.REGISTER_USER);
			preparedStatement.setString(1,user.getUserName());
			preparedStatement.setString(2,user.getPassword());
			preparedStatement.setString(3,user.getRole());
			preparedStatement.setString(4,user.getMobileNumber());
			preparedStatement.setString(5,user.getPhoneNumber());
			preparedStatement.setString(6,user.getAddress());
			preparedStatement.setString(7,user.getEmail());
			
			queryResult=preparedStatement.executeUpdate();
			
			if(queryResult==0){
				logger.error("insertion failed");
				throw new HbmsException("Inserting failed");
			}
			else{
				preparedStatement2=connection.prepareStatement(QueryMapper.GET_USER_CURR_SEQ);
				resultSet=preparedStatement2.executeQuery();


				if(resultSet.next()){
					userId = resultSet.getInt(1);
					user.setUserId(userId);
				}
				logger.info("successfully inserted");
				return user;
			}
			
		}catch(Exception e){
			System.out.println("error in registration "+e);
		}finally{

			try {
				if(resultSet != null){
					resultSet.close();
				}
				if(preparedStatement != null){
					preparedStatement.close();
				}
				if(preparedStatement2!= null){
					preparedStatement.close();
				}
				if(connection != null){
					connection.close();
				}
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new HbmsException("Error in closing the database connections");
			}
		}
		return user;
	}

	
	
	
	
	
	@Override
	public User loginUser(User user) throws HbmsException {
		connection = DbConnection.getConnection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet =null;
		Integer userId = 0;
		 
		try{
			preparedStatement=connection.prepareStatement(QueryMapper.LOG_IN);
			preparedStatement.setString(1,user.getUserName());
			preparedStatement.setString(2,user.getPassword());
			
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()){
				userId = resultSet.getInt(1);
				user.setUserId(userId);
				user.setRole(resultSet.getString(3));
				user.setMobileNumber(resultSet.getString(5));
				user.setPhoneNumber(resultSet.getString(6));
				user.setAddress(resultSet.getString(7));
				user.setEmail(resultSet.getString(8));
			}
			logger.info("successfully logged in");
			return user;
			
			
		}catch(Exception e){
			System.out.println("exception occurred"+e);
		}finally{

			try {
				if(resultSet != null){
					resultSet.close();
				}
				if(preparedStatement != null){
					preparedStatement.close();
				}
				if(connection != null){
					connection.close();
				}
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new HbmsException("Error in closing the database connections");
			}
		}
		return user;
	}

	

}
