package com.cg.hbms.service;

import com.cg.hbms.dao.HbmsDaoImpl;
import com.cg.hbms.dao.IHbmsDao;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;

public class HbmsServiceImpl implements IHbmsService {
	
	IHbmsDao hbmsdao = new HbmsDaoImpl();
	@Override
	public User registerUser(User user) throws HbmsException {
		
		return hbmsdao.registerUser(user);
	}

	@Override
	public User loginUser(User user) throws HbmsException {
	
		return hbmsdao.loginUser(user);
	}

}
