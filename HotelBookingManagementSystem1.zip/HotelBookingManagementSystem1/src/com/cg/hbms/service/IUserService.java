package com.cg.hbms.service;

import java.util.List;

import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.exception.HbmsException;

public interface IUserService {

	public List<Hotel> getHotelList() throws HbmsException;//
	public List<RoomDetail> getRoomByHotel(Integer hotelId) throws HbmsException;
	public List<BookingDetail> getBookingByUser(Integer userId) throws HbmsException;//
	
	public BookingDetail bookRoom(BookingDetail bookingDetail) throws HbmsException;
	public RoomDetail getRoomById(Integer roomId) throws HbmsException;
}
