package com.cg.hbms.service;

import java.util.List;

import com.cg.hbms.entities.BookingDetail;
import com.cg.hbms.entities.Hotel;
import com.cg.hbms.entities.RoomDetail;
import com.cg.hbms.entities.User;
import com.cg.hbms.exception.HbmsException;

public interface IAdminService {

	// Hotel management
		public List<Hotel> getHotelList() throws HbmsException;
		public Hotel addHotel(Hotel hotel) throws HbmsException;
		public Hotel modifyHotel(Hotel hotel) throws HbmsException;
		public boolean deleteHotel(Integer hotelId) throws HbmsException;
		
		
		// Room management
		public List<RoomDetail> getRoomList() throws HbmsException;//
		public RoomDetail addRoom(RoomDetail room) throws HbmsException;//
		public RoomDetail modifyRoom(RoomDetail room) throws HbmsException;
		public boolean deleteRoom(RoomDetail roomId) throws HbmsException;
		
		
		// Generating Reports
		public List<BookingDetail> getBookingByHotel(Integer hotelId) throws HbmsException;//
		public List<User> getUserByHotel(Integer hotelId) throws HbmsException;
		public List<BookingDetail> getBookingByDate(String date) throws HbmsException;
		
}
